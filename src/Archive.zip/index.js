document.addEventListener('DOMContentLoaded',App.init())
